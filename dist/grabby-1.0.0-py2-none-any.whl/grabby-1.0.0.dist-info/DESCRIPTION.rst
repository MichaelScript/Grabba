Grabby is a command line tool / python module that allows you to copy directory trees from any OS based on user defined filters.


